package com.mindorks.test;

/**
 * Created by janisharali on 21/08/16.
 */
public class Image {

    String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
