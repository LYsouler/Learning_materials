package com.mindorks.placeholderview;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by janisharali on 18/08/16.
 */
public class ViewHolder extends RecyclerView.ViewHolder {

    /**
     *
     * @param itemView
     */
    public ViewHolder(View itemView) {
        super(itemView);
    }
}
